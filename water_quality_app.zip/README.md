# Web Application for Physico-Chemical Water Quality Assessment and Prediction in a Desalination Plant

**FR :** Application web développée avec Python et Streamlit pour analyser et prédire la qualité physico-chimique de l’eau dans une station de dessalement. Elle compare les résultats aux normes OMS et utilise l’IA (régression linéaire et MLP).

**EN :** Web application using Python and Streamlit to analyze and predict physico-chemical water quality in a desalination plant. It compares results to WHO standards and applies AI (Linear Regression and MLP) for prediction.
