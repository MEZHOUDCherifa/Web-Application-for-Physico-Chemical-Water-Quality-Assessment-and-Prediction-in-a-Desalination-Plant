
import streamlit as st
import pandas as pd
import matplotlib.pyplot as plt
from sklearn.linear_model import LinearRegression
from sklearn.neural_network import MLPRegressor

st.set_page_config(layout="wide")
st.title("💧 Analyse et Prédiction de la Qualité de l'Eau - Station de Dessalement")

# === Données fixes ===
semaine_labels = ["Semaine 1", "Semaine 2", "Semaine 3", "Semaine 4"]
data_physico = {
    "Semaine": semaine_labels,
    "Chlore": [0.42, 0.43, 0.4, 0.41],
    "Dureté": [69.88, 70.09, 69.61, 69.82],
    "Solides dissous": [306, 326, 334, 343],
    "PH": [8.39, 8.37, 8.37, 8.35],
    "Température": [18.6, 18.4, 18.8, 19.7],
    "Conductivité": [615, 652, 668, 685],
    "TAC": [60.21, 60.26, 60.05, 60.2],
    "TA": [60.07, 54.31, 59.77, 60.63],
    "Mg": [9.81, 14.88, 9.88, 9.26],
    "Ca": [60.07, 55.21, 59.63, 60.55]
}
data_chimique = {
    "Semaine": semaine_labels,
    "Bore": [0.8, 0.82, 0.84, 0.9],
    "Chlorure": [162, 143, 152, 169],
    "Nitrites": [2, 1.9, 1.2, 2.3],
    "Nitrates": [33.8, 39.9, 36.9, 38.1],
    "Sulfate": [60, 63, 67.8, 65.3],
    "Sodium": [40, 34, 42, 38],
    "Potassium": [13, 14.9, 12.6, 11.7],
    "Fer": [0.1, 0.24, 0.19, 0.22]
}

normes = {
    "Chlore": (0, 5),
    "Dureté": (65, 150),
    "Solides dissous": (150, 500),
    "PH": (6.5, 8.5),
    "Conductivité": (0, 1500),
    "TAC": (50, 65),
    "Mg": (0, 150),
    "Ca": (0, 75),
    "Bore": (0, 1),
    "Chlorure": (0, 250),
    "Nitrites": (0, 3),
    "Nitrates": (0, 50),
    "Sulfate": (0, 500),
    "Sodium": (0, 200),
    "Potassium": (0, 20),
    "Fer": (0, 0.3)
}

col1, col2 = st.columns(2)
with col1:
    st.subheader("Paramètres Physico-Chimiques")
    df_physico = pd.DataFrame(data_physico)
    st.dataframe(df_physico.set_index("Semaine"))
with col2:
    st.subheader("Paramètres Chimiques")
    df_chimique = pd.DataFrame(data_chimique)
    st.dataframe(df_chimique.set_index("Semaine"))

st.subheader("🔬 Comparaison aux normes OMS")
def comparer(df, normes):
    comparaisons = {}
    for param in df.columns[1:]:
        if param in normes:
            val_moy = df[param].mean()
            norme_min, norme_max = normes[param]
            if val_moy < norme_min:
                comparaisons[param] = f"⚠️ Trop bas ({val_moy:.2f} < {norme_min})"
            elif val_moy > norme_max:
                comparaisons[param] = f"⚠️ Trop élevé ({val_moy:.2f} > {norme_max})"
            else:
                comparaisons[param] = f"✅ Conforme ({val_moy:.2f})"
    return comparaisons

st.markdown("**Physico-chimiques :**")
st.json(comparer(df_physico, normes))
st.markdown("**Chimiques :**")
st.json(comparer(df_chimique, normes))

st.subheader("📈 Prédiction avec Intelligence Artificielle")
st.markdown("**Choisissez une variable cible pour la prédiction (par IA)**")
all_data = pd.concat([df_physico.set_index("Semaine"), df_chimique.set_index("Semaine")], axis=1)
features = st.multiselect("Variables explicatives (entrées)", options=all_data.columns.tolist())
target = st.selectbox("Variable cible (à prédire)", options=all_data.columns.tolist())

if features and target and target not in features:
    X = all_data[features].values
    y = all_data[target].values
    lr = LinearRegression().fit(X, y)
    y_pred_lr = lr.predict(X)
    mlp = MLPRegressor(hidden_layer_sizes=(10,), max_iter=2000, random_state=1)
    mlp.fit(X, y)
    y_pred_mlp = mlp.predict(X)

    st.markdown("**Comparaison des prédictions :**")
    fig, ax = plt.subplots(figsize=(10, 4))
    ax.plot(semaine_labels, y, label="Réel", marker='o')
    ax.plot(semaine_labels, y_pred_lr, label="Régression Linéaire", linestyle='--', marker='s')
    ax.plot(semaine_labels, y_pred_mlp, label="MLP", linestyle=':', marker='x')
    ax.set_title(f"Prédiction de {target}")
    ax.set_ylabel(target)
    ax.legend()
    ax.grid(True)
    st.pyplot(fig)
elif target in features:
    st.warning("La variable cible ne doit pas être incluse dans les variables d'entrée.")
